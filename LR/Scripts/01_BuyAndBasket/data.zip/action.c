Action()
{

	lr_start_transaction("clickToSite");

	return 0;
}